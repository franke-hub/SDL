// All permissions
grant {
	permission java.security.AllPermission;
};

